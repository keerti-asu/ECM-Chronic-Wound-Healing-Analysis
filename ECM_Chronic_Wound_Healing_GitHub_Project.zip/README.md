
# ECM-Based Therapies for Chronic Wound Healing

## Project Overview
This project analyzes the clinical effectiveness of extracellular matrix (ECM) therapies derived from amnion and chorion tissues in chronic wound treatment.

The dataset aggregates clinical outcomes from 13 trials comparing ECM-based treatments with standard-of-care (SOC).

## Key Questions
- Do ECM therapies improve wound healing rates?
- Do ECM treatments reduce healing time?
- What statistical relationship exists between healing rate and closure time?

## Tools
Python, Pandas, SciPy, Matplotlib, Seaborn

## Key Metrics
- Healing rate comparison
- Median healing time
- Correlation analysis

## Example Findings
- ECM healing rates outperform SOC across most trials.
- ECM groups show reduced median time to wound closure.
- Higher healing rates correlate with faster closure.

## Folder Structure
data/ – dataset  
notebooks/ – analysis notebook  
visuals/ – generated charts  
scripts/ – helper scripts  

## How to Run
1. Install requirements
```
pip install -r requirements.txt
```

2. Open notebook
```
jupyter notebook notebooks/ECM_wound_analysis.ipynb
```

## Skills Demonstrated
- Data cleaning
- Exploratory data analysis
- Statistical testing
- Healthcare data analytics
